# ELYCKER TRAVELLERS — Futuristic Kenya Travel Website

A responsive, travel-focused redesign featuring Kenya-only destinations, culture + nature experiences, a photo gallery, traveller testimonials, booking interactions, FAQ, and contact/social links.

## Files
- `index.html`
- `style.css`
- `script.js`

## Note about photos
The destination/gallery photos use web-hosted Unsplash image URLs, so an internet connection is required for those images to load. Replace the URLs with your own licensed photos for production.
